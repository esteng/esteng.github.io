"""
Data loading and featurization utilities. PROVIDED -- you do not need to
modify this file, and you do not need to understand every line, but skim it
so you know what shape of data your model will receive.

Pipeline:
  1. load_split(path)   -> list of (tokens, label) pairs
  2. build_vocab(...)   -> word -> index mapping, built from the TRAIN split only
  3. featurize(...)     -> dense bag-of-words numpy arrays (X, y)
"""

import re
import numpy as np

_TOKEN_RE = re.compile(r"[a-z']+")


def tokenize(text):
    """Lowercase and split into word tokens, stripping punctuation."""
    return _TOKEN_RE.findall(text.lower())


def load_split(path):
    """Reads a tab-separated (label, text) file into a list of (tokens, label)."""
    examples = []
    with open(path) as f:
        next(f)  # header
        for line in f:
            label_str, text = line.rstrip("\n").split("\t", 1)
            examples.append((tokenize(text), int(label_str)))
    return examples


def build_vocab(train_examples, min_count=5, max_vocab_size=3000):
    """Builds a word->index mapping from the training split only.

    Using the training vocabulary only (never dev/test) avoids leaking
    information about words that only appear at evaluation time.

    Real review text has a long tail of rare words (typos, names, etc.),
    so we drop anything appearing fewer than `min_count` times, then keep
    only the `max_vocab_size` most frequent remaining words. This keeps
    the feature dimension (and therefore the size of W1) manageable for a
    pure-numpy implementation. Ties in frequency are broken alphabetically
    so the resulting vocabulary is deterministic.
    """
    counts = {}
    for tokens, _ in train_examples:
        for tok in tokens:
            counts[tok] = counts.get(tok, 0) + 1
    candidates = [w for w, c in counts.items() if c >= min_count]
    candidates.sort(key=lambda w: (-counts[w], w))
    if max_vocab_size is not None:
        candidates = candidates[:max_vocab_size]
    vocab = sorted(candidates)
    return {word: idx for idx, word in enumerate(vocab)}


def featurize(examples, word_to_idx):
    """Converts (tokens, label) pairs into dense bag-of-words feature vectors.

    Features are BINARY (1.0 if a word occurs one or more times in the
    review, else 0.0), not raw counts. Two reasons:
      1. Real reviews vary a lot in length (word counts here range from
         under 10 to several hundred), so raw counts give inputs with wildly
         different scales, which makes plain SGD unstable unless the
         learning rate is tuned very low. Binary features keep every input
         entry in {0, 1}.
      2. It also happens to be a well-known result for this exact task:
         Pang, Lee, and Vaithyanathan (2002) found binary presence features
         outperform frequency counts for sentiment classification.

    Returns:
        X: float32 array of shape (num_examples, vocab_size)
        y: int64 array of shape (num_examples,)
    """
    X = np.zeros((len(examples), len(word_to_idx)), dtype=np.float32)
    y = np.zeros(len(examples), dtype=np.int64)
    for i, (tokens, label) in enumerate(examples):
        for tok in tokens:
            j = word_to_idx.get(tok)
            if j is not None:
                X[i, j] = 1.0
        y[i] = label
    return X, y


def load_dataset(data_dir="data", min_count=5, max_vocab_size=3000):
    """Convenience function: loads all three splits and featurizes them
    using a vocabulary built from the training split.

    Returns a dict with keys: 'word_to_idx', 'X_train', 'y_train',
    'X_dev', 'y_dev', 'X_test', 'y_test'.
    """
    train_examples = load_split(f"{data_dir}/train.tsv")
    dev_examples = load_split(f"{data_dir}/dev.tsv")
    test_examples = load_split(f"{data_dir}/test.tsv")

    word_to_idx = build_vocab(train_examples, min_count=min_count, max_vocab_size=max_vocab_size)

    X_train, y_train = featurize(train_examples, word_to_idx)
    X_dev, y_dev = featurize(dev_examples, word_to_idx)
    X_test, y_test = featurize(test_examples, word_to_idx)

    return {
        "word_to_idx": word_to_idx,
        "X_train": X_train, "y_train": y_train,
        "X_dev": X_dev, "y_dev": y_dev,
        "X_test": X_test, "y_test": y_test,
    }


if __name__ == "__main__":
    ds = load_dataset()
    print(f"vocab size: {len(ds['word_to_idx'])}")
    print(f"train: {ds['X_train'].shape}, dev: {ds['X_dev'].shape}, test: {ds['X_test'].shape}")
