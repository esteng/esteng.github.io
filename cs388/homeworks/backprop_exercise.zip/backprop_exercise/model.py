"""
YOUR TASK: implement a 2-layer MLP (one hidden layer) for binary sentiment
classification, using only numpy. Fill in every function/method marked
TODO. Do not import any ML library (no torch, no sklearn, no autograd of
any kind) -- the entire point is to write the forward and backward passes
by hand.

Architecture (x is a bag-of-words vector of size V = vocab_size):

    z1 = x @ W1 + b1            # (H,)
    h  = ReLU(z1)                # (H,)
    z2 = h @ W2 + b2            # (C,)  C = 2 (negative, positive)
    p  = softmax(z2)             # (C,)  predicted class probabilities

Loss (average cross-entropy over a batch of size N):

    L = -(1/N) * sum_i log( p_i[y_i] )

You will implement everything batched: X has shape (N, V) for a batch of N
examples, and every intermediate (Z1, H, Z2, P) has shape (N, H) or (N, C)
accordingly.

relu(), softmax(), and cross_entropy_loss() are provided below so you can
focus on the actual backprop mechanics (forward, backward, and the SGD
update). You will still need relu_grad() -- the derivative of ReLU -- since
that's an integral part of deriving backward().
"""

import numpy as np


def relu(z):
    """Provided: elementwise ReLU."""
    return np.maximum(0, z)


def relu_grad(z):
    """TODO: elementwise derivative of ReLU at z (1 where z > 0, else 0)."""
    raise NotImplementedError


def softmax(z):
    """Provided: row-wise softmax of z, shape (N, C) -> (N, C).

    The row max is subtracted before exponentiating for numerical
    stability (this does not change the result, since softmax is
    shift-invariant).
    """
    z_shifted = z - np.max(z, axis=1, keepdims=True)
    exp_z = np.exp(z_shifted)
    return exp_z / np.sum(exp_z, axis=1, keepdims=True)


def cross_entropy_loss(probs, y):
    """Provided: average cross-entropy loss.

    Args:
        probs: (N, C) predicted probabilities (rows sum to 1)
        y: (N,) integer class labels in [0, C)

    Returns:
        scalar float: mean over the batch of -log(probs[i, y[i]])
    """
    n = probs.shape[0]
    p_true = np.clip(probs[np.arange(n), y], 1e-12, 1.0)
    return float(-np.mean(np.log(p_true)))


class TwoLayerMLP:
    """A 2-layer (1 hidden layer) MLP with ReLU activation and softmax output,
    trained with plain mini-batch SGD.
    """

    def __init__(self, input_dim, hidden_dim, num_classes=2, seed=0):
        rng = np.random.default_rng(seed)
        # Small random init for weights, zeros for biases. Scaling by
        # sqrt(1 / fan_in) keeps activations from exploding/vanishing.
        self.W1 = rng.normal(0, 1.0 / np.sqrt(input_dim), size=(input_dim, hidden_dim))
        self.b1 = np.zeros(hidden_dim)
        self.W2 = rng.normal(0, 1.0 / np.sqrt(hidden_dim), size=(hidden_dim, num_classes))
        self.b2 = np.zeros(num_classes)

    def forward(self, X):
        """TODO: run the forward pass for a batch of inputs.

        Args:
            X: (N, V) bag-of-words feature matrix

        Returns:
            probs: (N, C) predicted class probabilities
            cache: a dict (or tuple) with whatever intermediate values
                   (e.g. X, Z1, H, Z2) you will need in backward()
        """
        raise NotImplementedError

    def backward(self, cache, y):
        """TODO: run the backward pass and return the gradient of the mean
        cross-entropy loss with respect to every parameter.

        Args:
            cache: whatever forward() returned
            y: (N,) integer class labels

        Returns:
            a dict with keys 'W1', 'b1', 'W2', 'b2' mapping to gradients
            with the SAME shapes as self.W1, self.b1, self.W2, self.b2.

        Derivation reminder (softmax + cross-entropy combine nicely):
            dZ2 = (probs - one_hot(y)) / N          # (N, C)
            dW2 = H.T @ dZ2                          # (H, C)
            db2 = sum over N of dZ2                  # (C,)
            dH  = dZ2 @ W2.T                         # (N, H)
            dZ1 = dH * relu_grad(Z1)                 # (N, H)
            dW1 = X.T @ dZ1                          # (V, H)
            db1 = sum over N of dZ1                  # (H,)
        """
        raise NotImplementedError

    def step(self, grads, lr):
        """TODO: apply one SGD update: param -= lr * grad, for all four
        parameters (W1, b1, W2, b2)."""
        raise NotImplementedError

    def predict(self, X):
        """Provided: returns the predicted class (argmax) for each row of X."""
        probs, _ = self.forward(X)
        return np.argmax(probs, axis=1)
