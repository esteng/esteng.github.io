# Assignment: Backprop From Scratch (2-Layer MLP for Sentiment Classification)

In this assignment you will implement, using **only numpy**, a 2-layer
multilayer perceptron (MLP) and train it with backpropagation and
mini-batch stochastic gradient descent (SGD) on a real sentiment
classification task.

Do not use PyTorch, TensorFlow, JAX, scikit-learn, or any library
that provides automatic differentiation or pre-built neural network layers.
The entire point of the assignment is to derive and implement the forward
and backward passes yourself.

## Setup

Requires Python 3.9+ (tested with Python 3.13). The only dependency is
numpy:
```
pip install -r requirements.txt
```

## The task

The data is a subset of the IMDB movie review dataset (Maas et al., 2011):
real movie reviews written by real people, labeled positive (1) or
negative (0). For example (trimmed for length):

```
1    I don't remember when I first heard about this movie, but I rented
     it about six years ago, and it still remains one of my favorite
     comedies. I will admit, you probably will despise this movie if...
0    This film limps from self indulgent moment to self indulgent
     moment, promising to develop into something worth hanging on for.
     But it doesn't. It's flat, self conscious, unimaginative...
```

Features are bag-of-words (BoW) indicators (does word *w* appear in this
review, yes/no). All
preprocessing is provided for you.

## Files

| File | What it is |
|---|---|
| `data/train.tsv`, `data/dev.tsv`, `data/test.tsv` | The dataset (3000/500/500 reviews). Do not modify. |
| `data_utils.py` | **Provided.** Tokenization, vocabulary building, and BoW featurization. |
| `model.py` | **Your work goes here.** Skeleton for the MLP: forward, backward, and the SGD update. |
| `train.py` | **Provided.** Training loop that calls your `model.py` functions and reports train/dev/test accuracy. |
| `make_data.py` | **Provided, informational only.** The script that built the dataset from the raw IMDB download (you don't need to run it). |

## What you need to implement

`relu(z)`, `softmax(z)`, and `cross_entropy_loss(probs, y)` are already
implemented for you, so you can focus on the actual backprop mechanics.
Everything else you need to fill in is marked `TODO` /
`raise NotImplementedError` in `model.py`:

1. `relu_grad(z)` — the derivative of ReLU. You'll need this in `backward()`.
2. `TwoLayerMLP.forward(X)` — the forward pass: `X -> Z1 -> H -> Z2 -> probs`.
3. `TwoLayerMLP.backward(cache, y)` — the backward pass: compute the
   gradient of the loss with respect to `W1`, `b1`, `W2`, `b2` by hand,
   using the chain rule.
4. `TwoLayerMLP.step(grads, lr)` — the SGD parameter update.

Read the docstrings in `model.py` carefully — they include the exact shapes
expected and, for `backward()`, the derivative equations you need to
implement (deriving them yourself on paper first is strongly recommended
and will make the implementation nearly mechanical).

## How to check your work

Run:
```
python train.py
```
You should see training loss decrease and train/dev accuracy increase
over epochs.

You can experiment with hyperparameters:
```
python train.py --hidden_dim 32 --lr 0.1 --epochs 20
```

## What accuracy should I expect?

A correct implementation with the default hyperparameters
(`hidden_dim=16`, `lr=0.1`, `epochs=20`, `batch_size=16`) should reach
roughly **83-86% dev accuracy** (best epoch, typically within the first
10 epochs) and a similar test accuracy. Training accuracy will climb to
100% well before that as the model starts to overfit the training set. 

