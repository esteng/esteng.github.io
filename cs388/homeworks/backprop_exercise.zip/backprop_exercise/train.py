"""
PROVIDED training script. You should not need to modify this file to
complete the assignment, but feel free to tweak hyperparameters via the
command-line flags below while you experiment.

Usage:
    python train.py
    python train.py --hidden_dim 32 --lr 0.2 --epochs 20
"""

import argparse
import numpy as np

from data_utils import load_dataset
from model import TwoLayerMLP, cross_entropy_loss


def accuracy(model, X, y):
    preds = model.predict(X)
    return float(np.mean(preds == y))


def iterate_minibatches(X, y, batch_size, rng):
    n = X.shape[0]
    order = rng.permutation(n)
    for start in range(0, n, batch_size):
        idx = order[start:start + batch_size]
        yield X[idx], y[idx]


def train(args):
    ds = load_dataset(min_count=args.min_count, max_vocab_size=args.max_vocab_size)
    X_train, y_train = ds["X_train"], ds["y_train"]
    X_dev, y_dev = ds["X_dev"], ds["y_dev"]
    X_test, y_test = ds["X_test"], ds["y_test"]

    print(f"vocab size: {len(ds['word_to_idx'])}")
    print(f"train/dev/test sizes: {X_train.shape[0]}/{X_dev.shape[0]}/{X_test.shape[0]}")

    model = TwoLayerMLP(
        input_dim=X_train.shape[1],
        hidden_dim=args.hidden_dim,
        num_classes=2,
        seed=args.seed,
    )
    rng = np.random.default_rng(args.seed)

    best_dev_acc = -1.0
    best_epoch = -1
    for epoch in range(1, args.epochs + 1):
        epoch_losses = []
        for X_batch, y_batch in iterate_minibatches(X_train, y_train, args.batch_size, rng):
            probs, cache = model.forward(X_batch)
            loss = cross_entropy_loss(probs, y_batch)
            grads = model.backward(cache, y_batch)
            model.step(grads, args.lr)
            epoch_losses.append(loss)

        train_loss = float(np.mean(epoch_losses))
        train_acc = accuracy(model, X_train, y_train)
        dev_acc = accuracy(model, X_dev, y_dev)
        print(f"epoch {epoch:3d} | train loss {train_loss:.4f} | "
              f"train acc {train_acc:.3f} | dev acc {dev_acc:.3f}")

        if dev_acc > best_dev_acc:
            best_dev_acc = dev_acc
            best_epoch = epoch

    test_acc = accuracy(model, X_test, y_test)
    print()
    print(f"best dev acc: {best_dev_acc:.3f} (epoch {best_epoch})")
    print(f"final test acc: {test_acc:.3f}")


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--hidden_dim", type=int, default=16)
    p.add_argument("--lr", type=float, default=0.1)
    p.add_argument("--epochs", type=int, default=30)
    p.add_argument("--batch_size", type=int, default=16)
    p.add_argument("--min_count", type=int, default=5)
    p.add_argument("--max_vocab_size", type=int, default=3000)
    p.add_argument("--seed", type=int, default=0)
    return p.parse_args()


if __name__ == "__main__":
    train(parse_args())
